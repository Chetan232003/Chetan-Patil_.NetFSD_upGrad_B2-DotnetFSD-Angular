﻿using ContactManagement.Dal.Models;
using Microsoft.EntityFrameworkCore;


namespace ContactManagement.Dal
{
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions options) : base(options) { }
        
        public DbSet <ContactInfo> Contacts { get; set; }
        public DbSet <Company> Company { get; set; }
        public DbSet <Department> Departments { get; set; }
        public DbSet <User> User { get; set; }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {

            modelBuilder.Entity<ContactInfo>()
                .HasKey(c => c.ContactId);


            modelBuilder.Entity<ContactInfo>()
                .HasOne(c => c.Company)
                .WithMany(c => c.Contacts)
                .HasForeignKey(c => c.CompanyId);

            modelBuilder.Entity<ContactInfo>()
                .HasOne(c => c.Department)
                .WithMany( c=> c.Contacts)
                .HasForeignKey(c => c.DepartmentId);
        }
       
    }
}
