﻿using ContactManagement.Dal.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ContactManagement.Dal.Repository
{
    public interface IContactRepository
    {

        Task<IEnumerable<ContactInfo>> GetAll();
        Task<ContactInfo> GetById(int id);
        Task Add(ContactInfo contact);
        Task Update(ContactInfo contact);
        Task DeleteById(int id);


    }
}
