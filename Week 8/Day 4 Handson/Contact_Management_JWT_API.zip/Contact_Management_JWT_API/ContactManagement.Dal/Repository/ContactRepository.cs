﻿using ContactManagement.Dal.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ContactManagement.Dal.Repository
{
    public class ContactRepository : IContactRepository
    {
        private readonly AppDbContext _context;
        public ContactRepository(AppDbContext context)
        {
            this._context = context;
        }
        public async Task  Add(ContactInfo contact)
        {
           
            await _context.Contacts.AddAsync(contact);
            await _context.SaveChangesAsync();
        }

        public async Task DeleteById(int id)
        {
            var data = await _context.Contacts.FindAsync(id);
            _context.Contacts.Remove(data);
            await _context.SaveChangesAsync();
        }

        public async Task<IEnumerable<ContactInfo>> GetAll()
        {
            return await _context.Contacts
                .Include(c => c.Company)
                .Include(c => c.Department)
                .ToListAsync();
        }

        public async Task<ContactInfo> GetById(int id)
        {
            return await _context.Contacts
                .Include(c => c.Company)
                .Include(c => c.Department)
                .FirstOrDefaultAsync(x => x.ContactId == id);
        }

        public async Task Update(ContactInfo contact)
        {
             _context.Contacts.Update(contact);
            await _context.SaveChangesAsync();
        }
    }
}
