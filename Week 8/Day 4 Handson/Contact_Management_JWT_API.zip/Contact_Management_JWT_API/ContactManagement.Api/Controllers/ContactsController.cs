﻿using ContactManagement.Dal.Models;
using ContactManagement.Dal.Repository;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace ContactManagement.Api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ContactsController : ControllerBase
    {
        private readonly IContactRepository _repo;

        public ContactsController(IContactRepository repo)
        {
            this._repo = repo;
        }

        [HttpGet]
        public async Task<IActionResult> getall()
        {
            await _repo.GetAll();
            return Ok();
        }
        [HttpGet("{id}")]
        public async Task<IActionResult> getById(int id)
        {
            var data = await _repo.GetById(id);
            if (data == null)
                return NotFound("Contact Not Found");

            return Ok(data);
        }

        [Authorize(Roles = "Admin")]
        [HttpPost]
        public async Task<IActionResult> create(ContactInfo contact)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            await _repo.Add(contact);

            return CreatedAtAction(nameof(getById),
                new { id = contact.ContactId }, contact);
        }

        [Authorize(Roles = "Admin")]
        [HttpPut("{id}")]
        public async Task<IActionResult> Update(int id, ContactInfo contact)
        {
            if (id != contact.ContactId)
                return BadRequest("ID Mismatch");

            var exist = await _repo.GetById(id);
            if (exist == null)
                return NotFound("Contact Not Exist");
            await _repo.Update(contact);

            return Ok("Update Successfully");
        }
        [Authorize(Roles ="Admin")]
        [HttpDelete]
        public async Task<IActionResult> Delete(int id)
        {
            var data = _repo.GetById(id);
            if (data == null)
                return NotFound("Contact Not Found");

            await _repo.DeleteById(id);
            return Ok("Deleted Successfully");

        }
    }
}
