using System.ComponentModel.DataAnnotations;

namespace AppUi.Models
{
    public class LoginViewModel
    {
        [Required] [EmailAddress] public string EmailId { get; set; } = string.Empty;
        [Required] [DataType(DataType.Password)] public string Password { get; set; } = string.Empty;
    }

    public class RegisterViewModel
    {
        [Required] [EmailAddress] public string EmailId { get; set; } = string.Empty;

        [Required] [StringLength(50, MinimumLength = 1)]
        public string UserName { get; set; } = string.Empty;

        [Required] [StringLength(20, MinimumLength = 6)]
        [DataType(DataType.Password)]
        public string Password { get; set; } = string.Empty;

        [Compare("Password", ErrorMessage = "Passwords do not match")]
        [DataType(DataType.Password)]
        public string ConfirmPassword { get; set; } = string.Empty;
    }

    public class EventViewModel
    {
        public int EventId { get; set; }

        [Required] [StringLength(50, MinimumLength = 1)]
        public string EventName { get; set; } = string.Empty;

        [Required] [StringLength(50, MinimumLength = 1)]
        public string EventCategory { get; set; } = string.Empty;

        [Required] [DataType(DataType.Date)]
        [Display(Name = "Event Date")]
        public DateTime EventDate { get; set; } = DateTime.Now.AddDays(1);

        public string? Description { get; set; }

        public string Status { get; set; } = "Active";
    }

    public class SessionViewModel
    {
        public int SessionId { get; set; }

        [Required] public int EventId { get; set; }

        [Required] [StringLength(50, MinimumLength = 1)]
        public string SessionTitle { get; set; } = string.Empty;

        public int? SpeakerId { get; set; }
        public string? Description { get; set; }

        [Required] [DataType(DataType.DateTime)]
        public DateTime SessionStart { get; set; }

        [Required] [DataType(DataType.DateTime)]
        public DateTime SessionEnd { get; set; }

        public string? SessionUrl { get; set; }

        public string? EventName { get; set; }
        public string? SpeakerName { get; set; }
    }

    public class SpeakerViewModel
    {
        public int SpeakerId { get; set; }

        [Required] [StringLength(50, MinimumLength = 1)]
        public string SpeakerName { get; set; } = string.Empty;
    }

    public class AssignSpeakerViewModel
    {
        [Required] public int SessionId { get; set; }
        [Required] public int SpeakerId { get; set; }
        public string? SessionTitle { get; set; }
        public List<DAL.Models.SpeakersDetails> Speakers { get; set; } = new();
    }

    public class ParticipantDashboardViewModel
    {
        public string UserName { get; set; } = string.Empty;
        public List<DAL.Models.ParticipantEventDetails> RegisteredEvents { get; set; } = new();
    }
}
