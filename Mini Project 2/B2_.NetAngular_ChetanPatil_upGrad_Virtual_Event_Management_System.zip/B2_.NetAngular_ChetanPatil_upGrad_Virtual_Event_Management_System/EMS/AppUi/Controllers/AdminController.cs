using AppUi.Models;
using DAL.Models;
using DAL.Repository;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace AppUi.Controllers
{
    public class AdminController : Controller
    {
        private readonly IEventRepository _eventRepo;
        private readonly ISessionRepository _sessionRepo;
        private readonly ISpeakerRepository _speakerRepo;
        private readonly IParticipantEventRepository _participantRepo;

        public AdminController(IEventRepository er, ISessionRepository sr,
            ISpeakerRepository spr, IParticipantEventRepository pr)
        {
            _eventRepo = er; _sessionRepo = sr; _speakerRepo = spr; _participantRepo = pr;
        }

        private bool IsAdmin() => HttpContext.Session.GetString("UserRole") == "Admin";

        // Dashboard
        public async Task<IActionResult> Dashboard()
        {
            if (!IsAdmin()) return RedirectToAction("AdminLogin", "Account");
            var events = await _eventRepo.GetAllAsync();
            ViewBag.EventCount = events.Count();
            ViewBag.ActiveCount = events.Count(e => e.Status == "Active");
            ViewBag.SpeakerCount = (await _speakerRepo.GetAllAsync()).Count();
            ViewBag.SessionCount = (await _sessionRepo.GetAllAsync()).Count();
            return View(events);
        }

        // Events
        public async Task<IActionResult> Events()
        {
            if (!IsAdmin()) return RedirectToAction("AdminLogin", "Account");
            return View(await _eventRepo.GetAllAsync());
        }

        public IActionResult AddEvent()
        {
            if (!IsAdmin()) return RedirectToAction("AdminLogin", "Account");
            return View(new EventViewModel());
        }

        [HttpPost]
        public async Task<IActionResult> AddEvent(EventViewModel model)
        {
            if (!IsAdmin()) return RedirectToAction("AdminLogin", "Account");
            if (model.EventDate <= DateTime.Today)
                ModelState.AddModelError("EventDate", "Event date must be in the future.");
            if (!ModelState.IsValid) return View(model);

            await _eventRepo.AddAsync(new EventDetails
            {
                EventName = model.EventName,
                EventCategory = model.EventCategory,
                EventDate = model.EventDate,
                Description = model.Description,
                Status = model.Status
            });
            TempData["Success"] = "Event added successfully!";
            return RedirectToAction("Events");
        }

        public async Task<IActionResult> EditEvent(int id)
        {
            if (!IsAdmin()) return RedirectToAction("AdminLogin", "Account");
            var ev = await _eventRepo.GetByIdAsync(id);
            if (ev == null) return NotFound();
            return View(new EventViewModel
            {
                EventId = ev.EventId, EventName = ev.EventName,
                EventCategory = ev.EventCategory, EventDate = ev.EventDate,
                Description = ev.Description, Status = ev.Status
            });
        }

        [HttpPost]
        public async Task<IActionResult> EditEvent(EventViewModel model)
        {
            if (!IsAdmin()) return RedirectToAction("AdminLogin", "Account");
            if (model.EventDate <= DateTime.Today)
                ModelState.AddModelError("EventDate", "Event date must be in the future.");
            if (!ModelState.IsValid) return View(model);

            var ev = await _eventRepo.GetByIdAsync(model.EventId);
            if (ev == null) return NotFound();
            ev.EventName = model.EventName; ev.EventCategory = model.EventCategory;
            ev.EventDate = model.EventDate; ev.Description = model.Description;
            ev.Status = model.Status;
            await _eventRepo.UpdateAsync(ev);
            TempData["Success"] = "Event updated successfully!";
            return RedirectToAction("Events");
        }

        [HttpPost]
        public async Task<IActionResult> DeleteEvent(int id)
        {
            if (!IsAdmin()) return RedirectToAction("AdminLogin", "Account");
            await _eventRepo.DeleteAsync(id);
            TempData["Success"] = "Event deleted.";
            return RedirectToAction("Events");
        }

        [HttpPost]
        public async Task<IActionResult> ToggleStatus(int id)
        {
            if (!IsAdmin()) return RedirectToAction("AdminLogin", "Account");
            var ev = await _eventRepo.GetByIdAsync(id);
            if (ev != null)
            {
                ev.Status = ev.Status == "Active" ? "In-Active" : "Active";
                await _eventRepo.UpdateAsync(ev);
            }
            return RedirectToAction("Events");
        }

        //  Sessions 
        public async Task<IActionResult> Sessions(int? eventId)
        {
            if (!IsAdmin()) return RedirectToAction("AdminLogin", "Account");
            var sessions = eventId.HasValue
                ? await _sessionRepo.GetByEventAsync(eventId.Value)
                : await _sessionRepo.GetAllAsync();
            ViewBag.Events = new SelectList(await _eventRepo.GetAllAsync(), "EventId", "EventName", eventId);
            ViewBag.SelectedEventId = eventId;
            return View(sessions);
        }

        public async Task<IActionResult> AddSession(int? eventId)
        {
            if (!IsAdmin()) return RedirectToAction("AdminLogin", "Account");
            var events = await _eventRepo.GetAllAsync();
            if (!events.Any()) { TempData["Error"] = "Please create an event first."; return RedirectToAction("Events"); }
            ViewBag.Events = new SelectList(events, "EventId", "EventName", eventId);
            ViewBag.Speakers = new SelectList(await _speakerRepo.GetAllAsync(), "SpeakerId", "SpeakerName");
            return View(new SessionViewModel { EventId = eventId ?? 0 });
        }

        [HttpPost]
        public async Task<IActionResult> AddSession(SessionViewModel model)
        {
            if (!IsAdmin()) return RedirectToAction("AdminLogin", "Account");
            if (model.SessionEnd <= model.SessionStart)
                ModelState.AddModelError("SessionEnd", "Session end must be after session start.");
            if (!ModelState.IsValid)
            {
                ViewBag.Events = new SelectList(await _eventRepo.GetAllAsync(), "EventId", "EventName", model.EventId);
                ViewBag.Speakers = new SelectList(await _speakerRepo.GetAllAsync(), "SpeakerId", "SpeakerName", model.SpeakerId);
                return View(model);
            }
            await _sessionRepo.AddAsync(new SessionInfo
            {
                EventId = model.EventId, SessionTitle = model.SessionTitle,
                SpeakerId = model.SpeakerId, Description = model.Description,
                SessionStart = model.SessionStart, SessionEnd = model.SessionEnd,
                SessionUrl = model.SessionUrl
            });
            TempData["Success"] = "Session added successfully!";
            return RedirectToAction("Sessions");
        }

        [HttpPost]
        public async Task<IActionResult> DeleteSession(int id)
        {
            if (!IsAdmin()) return RedirectToAction("AdminLogin", "Account");
            await _sessionRepo.DeleteAsync(id);
            TempData["Success"] = "Session deleted.";
            return RedirectToAction("Sessions");
        }

        // Speakers 
        public async Task<IActionResult> Speakers()
        {
            if (!IsAdmin()) return RedirectToAction("AdminLogin", "Account");
            return View(await _speakerRepo.GetAllAsync());
        }

        [HttpPost]
        public async Task<IActionResult> AddSpeaker(SpeakerViewModel model)
        {
            if (!IsAdmin()) return RedirectToAction("AdminLogin", "Account");
            if (!ModelState.IsValid) { TempData["Error"] = "Invalid speaker name."; return RedirectToAction("Speakers"); }
            await _speakerRepo.AddAsync(new SpeakersDetails { SpeakerName = model.SpeakerName });
            TempData["Success"] = "Speaker added!";
            return RedirectToAction("Speakers");
        }

        [HttpPost]
        public async Task<IActionResult> DeleteSpeaker(int id)
        {
            if (!IsAdmin()) return RedirectToAction("AdminLogin", "Account");
            await _speakerRepo.DeleteAsync(id);
            TempData["Success"] = "Speaker removed.";
            return RedirectToAction("Speakers");
        }

        // Assign Speaker 
        public async Task<IActionResult> AssignSpeaker(int sessionId)
        {
            if (!IsAdmin()) return RedirectToAction("AdminLogin", "Account");
            var session = await _sessionRepo.GetByIdAsync(sessionId);
            if (session == null) return NotFound();
            var speakers = await _speakerRepo.GetAllAsync();
            if (!speakers.Any()) { TempData["Error"] = "Please add speakers first."; return RedirectToAction("Sessions"); }
            return View(new AssignSpeakerViewModel
            {
                SessionId = sessionId, SessionTitle = session.SessionTitle,
                Speakers = speakers.ToList()
            });
        }

        [HttpPost]
        public async Task<IActionResult> AssignSpeaker(AssignSpeakerViewModel model)
        {
            if (!IsAdmin()) return RedirectToAction("AdminLogin", "Account");
            await _sessionRepo.AssignSpeakerAsync(model.SessionId, model.SpeakerId);
            TempData["Success"] = "Speaker assigned!";
            return RedirectToAction("Sessions");
        }

        //  View Event with Sessions 
        public async Task<IActionResult> EventDetails(int id)
        {
            if (!IsAdmin()) return RedirectToAction("AdminLogin", "Account");
            var ev = await _eventRepo.GetWithSessionsAsync(id);
            if (ev == null) return NotFound();
            return View(ev);
        }
    }
}
