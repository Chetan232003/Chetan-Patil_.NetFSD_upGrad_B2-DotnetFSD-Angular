using AppUi.Models;
using DAL.Models;
using DAL.Repository;
using Microsoft.AspNetCore.Mvc;

namespace AppUi.Controllers
{
    public class ParticipantController : Controller
    {
        private readonly IEventRepository _eventRepo;
        private readonly IParticipantEventRepository _participantRepo;
        private readonly ISessionRepository _sessionRepo;

        public ParticipantController(IEventRepository er, IParticipantEventRepository pr, ISessionRepository sr)
        {
            _eventRepo = er; _participantRepo = pr; _sessionRepo = sr;
        }

        private bool IsParticipant() => HttpContext.Session.GetString("UserRole") == "Participant";
        private string? GetEmail() => HttpContext.Session.GetString("UserEmail");

        public async Task<IActionResult> Dashboard()
        {
            if (!IsParticipant()) return RedirectToAction("Login", "Account");
            var email = GetEmail()!;
            var registered = await _participantRepo.GetByParticipantAsync(email);
            return View(new ParticipantDashboardViewModel
            {
                UserName = HttpContext.Session.GetString("UserName") ?? email,
                RegisteredEvents = registered.ToList()
            });
        }

        public async Task<IActionResult> RegisterForEvent(int eventId)
        {
            if (!IsParticipant()) return RedirectToAction("Login", "Account");
            var email = GetEmail()!;
            if (await _participantRepo.IsRegisteredAsync(email, eventId))
            {
                TempData["Info"] = "You are already registered for this event.";
                return RedirectToAction("Index", "Home");
            }
            await _participantRepo.RegisterAsync(new ParticipantEventDetails
            {
                ParticipantEmailId = email,
                EventId = eventId,
                IsAttended = false
            });
            TempData["Success"] = "Successfully registered for the event!";
            return RedirectToAction("Dashboard");
        }

        [HttpPost]
        public async Task<IActionResult> MarkAttendance(int id, bool attended)
        {
            if (!IsParticipant()) return RedirectToAction("Login", "Account");
            await _participantRepo.MarkAttendanceAsync(id, attended);
            return RedirectToAction("Dashboard");
        }

        public async Task<IActionResult> EventSessions(int eventId)
        {
            if (!IsParticipant()) return RedirectToAction("Login", "Account");
            var ev = await _eventRepo.GetWithSessionsAsync(eventId);
            if (ev == null) return NotFound();
            return View(ev);
        }
    }
}
