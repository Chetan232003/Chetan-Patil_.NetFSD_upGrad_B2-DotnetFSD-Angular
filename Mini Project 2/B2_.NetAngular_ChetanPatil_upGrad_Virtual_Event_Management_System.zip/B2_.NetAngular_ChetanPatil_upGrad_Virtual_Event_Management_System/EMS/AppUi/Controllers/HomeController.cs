using DAL.Repository;
using Microsoft.AspNetCore.Mvc;

namespace AppUi.Controllers
{
    public class HomeController : Controller
    {
        private readonly IEventRepository _eventRepo;
        public HomeController(IEventRepository eventRepo) => _eventRepo = eventRepo;

        public async Task<IActionResult> Index()
        {
            var events = await _eventRepo.GetActiveAsync();
            return View(events);
        }

        public async Task<IActionResult> EventDetails(int id)
        {
            var ev = await _eventRepo.GetWithSessionsAsync(id);
            if (ev == null) return NotFound();
            return View(ev);
        }

        public async Task<IActionResult> SessionDetails(int id)
        {
            var sessions = await _eventRepo.GetWithSessionsAsync(id);
            return View(sessions);
        }
    }
}
