using AppUi.Models;
using DAL.Models;
using DAL.Repository;
using Microsoft.AspNetCore.Mvc;

namespace AppUi.Controllers
{
    public class AccountController : Controller
    {
        private readonly IUserRepository _userRepo;
        public AccountController(IUserRepository userRepo) => _userRepo = userRepo;

        // GET: Admin Login
        public IActionResult AdminLogin() => View();

        [HttpPost]
        public async Task<IActionResult> AdminLogin(LoginViewModel model)
        {
            if (!ModelState.IsValid) return View(model);
            var user = await _userRepo.AuthenticateAsync(model.EmailId, model.Password);
            if (user == null || user.Role != "Admin")
            {
                ModelState.AddModelError("", "Invalid admin credentials.");
                return View(model);
            }
            HttpContext.Session.SetString("UserEmail", user.EmailId);
            HttpContext.Session.SetString("UserName", user.UserName);
            HttpContext.Session.SetString("UserRole", user.Role);
            return RedirectToAction("Dashboard", "Admin");
        }

        // GET: Participant Register
        public IActionResult Register() => View();

        [HttpPost]
        public async Task<IActionResult> Register(RegisterViewModel model)
        {
            if (!ModelState.IsValid) return View(model);
            if (await _userRepo.EmailExistsAsync(model.EmailId))
            {
                ModelState.AddModelError("EmailId", "This email is already registered.");
                return View(model);
            }
            var user = new UserInfo
            {
                EmailId = model.EmailId,
                UserName = model.UserName,
                Password = model.Password,
                Role = "Participant"
            };
            await _userRepo.AddAsync(user);
            TempData["Success"] = "Registration successful! Please login.";
            return RedirectToAction("Login");
        }

        // GET: Participant Login
        public IActionResult Login() => View();

        [HttpPost]
        public async Task<IActionResult> Login(LoginViewModel model)
        {
            if (!ModelState.IsValid) return View(model);
            var user = await _userRepo.AuthenticateAsync(model.EmailId, model.Password);
            if (user == null || user.Role != "Participant")
            {
                ModelState.AddModelError("", "Invalid credentials.");
                return View(model);
            }
            HttpContext.Session.SetString("UserEmail", user.EmailId);
            HttpContext.Session.SetString("UserName", user.UserName);
            HttpContext.Session.SetString("UserRole", user.Role);
            return RedirectToAction("Dashboard", "Participant");
        }

        public IActionResult Logout()
        {
            HttpContext.Session.Clear();
            return RedirectToAction("Index", "Home");
        }
    }
}
