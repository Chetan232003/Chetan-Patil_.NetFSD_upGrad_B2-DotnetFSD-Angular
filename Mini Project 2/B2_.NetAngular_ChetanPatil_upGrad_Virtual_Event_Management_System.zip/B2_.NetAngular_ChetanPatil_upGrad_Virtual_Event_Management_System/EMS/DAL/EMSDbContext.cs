using Microsoft.EntityFrameworkCore;
using DAL.Models;

namespace DAL
{
    public class EMSDbContext : DbContext
    {
        public EMSDbContext(DbContextOptions<EMSDbContext> options) : base(options) { }

        public DbSet<UserInfo> Users { get; set; }
        public DbSet<EventDetails> Events { get; set; }
        public DbSet<SpeakersDetails> Speakers { get; set; }
        public DbSet<SessionInfo> Sessions { get; set; }
        public DbSet<ParticipantEventDetails> ParticipantEvents { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            // UserInfo
            modelBuilder.Entity<UserInfo>(entity =>
            {
                entity.HasKey(u => u.EmailId);
                entity.Property(u => u.UserName).IsRequired().HasMaxLength(50);
                entity.Property(u => u.Role).IsRequired();
                entity.Property(u => u.Password).IsRequired().HasMaxLength(20);
            });

            // EventDetails
            modelBuilder.Entity<EventDetails>(entity =>
            {
                entity.HasKey(e => e.EventId);
                entity.Property(e => e.EventName).IsRequired().HasMaxLength(50);
                entity.Property(e => e.EventCategory).IsRequired().HasMaxLength(50);
                entity.Property(e => e.EventDate).IsRequired();
                entity.Property(e => e.Status).HasDefaultValue("Active");
            });

            // SpeakersDetails
            modelBuilder.Entity<SpeakersDetails>(entity =>
            {
                entity.HasKey(s => s.SpeakerId);
                entity.Property(s => s.SpeakerName).IsRequired().HasMaxLength(50);
            });

            // SessionInfo
            modelBuilder.Entity<SessionInfo>(entity =>
            {
                entity.HasKey(s => s.SessionId);
                entity.Property(s => s.SessionTitle).IsRequired().HasMaxLength(50);
                entity.Property(s => s.SessionStart).IsRequired();
                entity.Property(s => s.SessionEnd).IsRequired();

                entity.HasOne(s => s.Event)
                      .WithMany(e => e.Sessions)
                      .HasForeignKey(s => s.EventId)
                      .OnDelete(DeleteBehavior.Cascade);

                entity.HasOne(s => s.Speaker)
                      .WithMany(sp => sp.Sessions)
                      .HasForeignKey(s => s.SpeakerId)
                      .OnDelete(DeleteBehavior.SetNull);
            });

            // ParticipantEventDetails
            modelBuilder.Entity<ParticipantEventDetails>(entity =>
            {
                entity.HasKey(p => p.ID);

                entity.HasOne(p => p.Participant)
                      .WithMany()
                      .HasForeignKey(p => p.ParticipantEmailId)
                      .OnDelete(DeleteBehavior.Restrict);

                entity.HasOne(p => p.Event)
                      .WithMany(e => e.Participants)
                      .HasForeignKey(p => p.EventId)
                      .OnDelete(DeleteBehavior.Restrict);

                entity.HasOne(p => p.Session)
                      .WithMany()
                      .HasForeignKey(p => p.SessionId)
                      .OnDelete(DeleteBehavior.Restrict);
            });

            // Seed admin user
            modelBuilder.Entity<UserInfo>().HasData(new UserInfo
            {
                EmailId = "admin@ems.com",
                UserName = "Administrator",
                Role = "Admin",
                Password = "Admin@123"
            });
        }
    }
}
