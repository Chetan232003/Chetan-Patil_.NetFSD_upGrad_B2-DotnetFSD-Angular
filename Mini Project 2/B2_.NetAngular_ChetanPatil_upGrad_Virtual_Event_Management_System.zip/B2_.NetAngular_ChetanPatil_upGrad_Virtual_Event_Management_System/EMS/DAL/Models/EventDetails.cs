using System.ComponentModel.DataAnnotations;

namespace DAL.Models
{
    public class EventDetails
    {
        [Key]
        public int EventId { get; set; }

        [Required]
        [StringLength(50, MinimumLength = 1)]
        public string EventName { get; set; } = string.Empty;

        [Required]
        [StringLength(50, MinimumLength = 1)]
        public string EventCategory { get; set; } = string.Empty;

        [Required]
        public DateTime EventDate { get; set; }

        public string? Description { get; set; }

        [RegularExpression("Active|In-Active", ErrorMessage = "Status must be Active or In-Active")]
        public string Status { get; set; } = "Active";

        // Navigation
        public ICollection<SessionInfo> Sessions { get; set; } = new List<SessionInfo>();
        public ICollection<ParticipantEventDetails> Participants { get; set; } = new List<ParticipantEventDetails>();
    }
}
