using System.ComponentModel.DataAnnotations;

namespace DAL.Models
{
    public class UserInfo
    {
        [Key]
        [Required]
        [EmailAddress]
        public string EmailId { get; set; } = string.Empty;

        [Required]
        [StringLength(50, MinimumLength = 1)]
        public string UserName { get; set; } = string.Empty;

        [Required]
        [RegularExpression("Admin|Participant", ErrorMessage = "Role must be Admin or Participant")]
        public string Role { get; set; } = string.Empty;

        [Required]
        [StringLength(20, MinimumLength = 6)]
        public string Password { get; set; } = string.Empty;
    }
}
