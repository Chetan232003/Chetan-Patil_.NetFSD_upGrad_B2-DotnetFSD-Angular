using System.ComponentModel.DataAnnotations;

namespace DAL.Models
{
    public class SpeakersDetails
    {
        [Key]
        public int SpeakerId { get; set; }

        [Required]
        [StringLength(50, MinimumLength = 1)]
        public string SpeakerName { get; set; } = string.Empty;

        // Navigation
        public ICollection<SessionInfo> Sessions { get; set; } = new List<SessionInfo>();
    }
}
