using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DAL.Models
{
    public class ParticipantEventDetails
    {
        [Key]
        public int ID { get; set; }

        [Required]
        [ForeignKey("Participant")]
        public string ParticipantEmailId { get; set; } = string.Empty;

        [Required]
        [ForeignKey("Event")]
        public int EventId { get; set; }

        public bool IsAttended { get; set; } = false;

        [ForeignKey("Session")]
        public int? SessionId { get; set; }

        // Navigation
        public UserInfo? Participant { get; set; }
        public EventDetails? Event { get; set; }
        public SessionInfo? Session { get; set; }
    }
}
