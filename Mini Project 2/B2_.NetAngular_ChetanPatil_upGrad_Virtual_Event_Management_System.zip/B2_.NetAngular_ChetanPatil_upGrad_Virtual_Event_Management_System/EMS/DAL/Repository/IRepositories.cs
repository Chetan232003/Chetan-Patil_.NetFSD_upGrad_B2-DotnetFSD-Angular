using DAL.Models;

namespace DAL.Repository
{
    public interface IUserRepository
    {
        Task<UserInfo?> GetByEmailAsync(string email);
        Task<UserInfo?> AuthenticateAsync(string email, string password);
        Task<bool> EmailExistsAsync(string email);
        Task AddAsync(UserInfo user);
        Task<IEnumerable<UserInfo>> GetAllParticipantsAsync();
    }

    public interface IEventRepository
    {
        Task<IEnumerable<EventDetails>> GetAllAsync();
        Task<IEnumerable<EventDetails>> GetActiveAsync();
        Task<EventDetails?> GetByIdAsync(int id);
        Task<EventDetails?> GetWithSessionsAsync(int id);
        Task AddAsync(EventDetails ev);
        Task UpdateAsync(EventDetails ev);
        Task DeleteAsync(int id);
    }

    public interface ISpeakerRepository
    {
        Task<IEnumerable<SpeakersDetails>> GetAllAsync();
        Task<SpeakersDetails?> GetByIdAsync(int id);
        Task AddAsync(SpeakersDetails speaker);
        Task DeleteAsync(int id);
    }

    public interface ISessionRepository
    {
        Task<IEnumerable<SessionInfo>> GetAllAsync();
        Task<IEnumerable<SessionInfo>> GetByEventAsync(int eventId);
        Task<SessionInfo?> GetByIdAsync(int id);
        Task AddAsync(SessionInfo session);
        Task UpdateAsync(SessionInfo session);
        Task DeleteAsync(int id);
        Task AssignSpeakerAsync(int sessionId, int speakerId);
    }

    public interface IParticipantEventRepository
    {
        Task<IEnumerable<ParticipantEventDetails>> GetByParticipantAsync(string email);
        Task<bool> IsRegisteredAsync(string email, int eventId);
        Task RegisterAsync(ParticipantEventDetails record);
        Task MarkAttendanceAsync(int id, bool attended);
        Task<IEnumerable<ParticipantEventDetails>> GetByEventAsync(int eventId);
    }
}
