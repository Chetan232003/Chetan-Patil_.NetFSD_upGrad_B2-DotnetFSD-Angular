using DAL.Models;
using Microsoft.EntityFrameworkCore;

namespace DAL.Repository
{
    public class UserRepository : IUserRepository
    {
        private readonly EMSDbContext _ctx;
        public UserRepository(EMSDbContext ctx) => _ctx = ctx;

        public async Task<UserInfo?> GetByEmailAsync(string email) =>
            await _ctx.Users.FindAsync(email);

        public async Task<UserInfo?> AuthenticateAsync(string email, string password) =>
            await _ctx.Users.FirstOrDefaultAsync(u => u.EmailId == email && u.Password == password);

        public async Task<bool> EmailExistsAsync(string email) =>
            await _ctx.Users.AnyAsync(u => u.EmailId == email);

        public async Task AddAsync(UserInfo user)
        {
            _ctx.Users.Add(user);
            await _ctx.SaveChangesAsync();
        }

        public async Task<IEnumerable<UserInfo>> GetAllParticipantsAsync() =>
            await _ctx.Users.Where(u => u.Role == "Participant").ToListAsync();
    }

    public class EventRepository : IEventRepository
    {
        private readonly EMSDbContext _ctx;
        public EventRepository(EMSDbContext ctx) => _ctx = ctx;

        public async Task<IEnumerable<EventDetails>> GetAllAsync() =>
            await _ctx.Events.Include(e => e.Sessions).ToListAsync();

        public async Task<IEnumerable<EventDetails>> GetActiveAsync() =>
            await _ctx.Events.Where(e => e.Status == "Active").Include(e => e.Sessions).ToListAsync();

        public async Task<EventDetails?> GetByIdAsync(int id) =>
            await _ctx.Events.FindAsync(id);

        public async Task<EventDetails?> GetWithSessionsAsync(int id) =>
            await _ctx.Events
                .Include(e => e.Sessions).ThenInclude(s => s.Speaker)
                .FirstOrDefaultAsync(e => e.EventId == id);

        public async Task AddAsync(EventDetails ev)
        {
            _ctx.Events.Add(ev);
            await _ctx.SaveChangesAsync();
        }

        public async Task UpdateAsync(EventDetails ev)
        {
            _ctx.Events.Update(ev);
            await _ctx.SaveChangesAsync();
        }

        public async Task DeleteAsync(int id)
        {
            var ev = await _ctx.Events.FindAsync(id);
            if (ev != null) { _ctx.Events.Remove(ev); await _ctx.SaveChangesAsync(); }
        }
    }

    public class SpeakerRepository : ISpeakerRepository
    {
        private readonly EMSDbContext _ctx;
        public SpeakerRepository(EMSDbContext ctx) => _ctx = ctx;

        public async Task<IEnumerable<SpeakersDetails>> GetAllAsync() =>
            await _ctx.Speakers.ToListAsync();

        public async Task<SpeakersDetails?> GetByIdAsync(int id) =>
            await _ctx.Speakers.FindAsync(id);

        public async Task AddAsync(SpeakersDetails speaker)
        {
            _ctx.Speakers.Add(speaker);
            await _ctx.SaveChangesAsync();
        }

        public async Task DeleteAsync(int id)
        {
            var sp = await _ctx.Speakers.FindAsync(id);
            if (sp != null) { _ctx.Speakers.Remove(sp); await _ctx.SaveChangesAsync(); }
        }
    }

    public class SessionRepository : ISessionRepository
    {
        private readonly EMSDbContext _ctx;
        public SessionRepository(EMSDbContext ctx) => _ctx = ctx;

        public async Task<IEnumerable<SessionInfo>> GetAllAsync() =>
            await _ctx.Sessions.Include(s => s.Event).Include(s => s.Speaker).ToListAsync();

        public async Task<IEnumerable<SessionInfo>> GetByEventAsync(int eventId) =>
            await _ctx.Sessions
                .Include(s => s.Speaker)
                .Where(s => s.EventId == eventId).ToListAsync();

        public async Task<SessionInfo?> GetByIdAsync(int id) =>
            await _ctx.Sessions.Include(s => s.Event).Include(s => s.Speaker)
                .FirstOrDefaultAsync(s => s.SessionId == id);

        public async Task AddAsync(SessionInfo session)
        {
            _ctx.Sessions.Add(session);
            await _ctx.SaveChangesAsync();
        }

        public async Task UpdateAsync(SessionInfo session)
        {
            _ctx.Sessions.Update(session);
            await _ctx.SaveChangesAsync();
        }

        public async Task DeleteAsync(int id)
        {
            var s = await _ctx.Sessions.FindAsync(id);
            if (s != null) { _ctx.Sessions.Remove(s); await _ctx.SaveChangesAsync(); }
        }

        public async Task AssignSpeakerAsync(int sessionId, int speakerId)
        {
            var session = await _ctx.Sessions.FindAsync(sessionId);
            if (session != null)
            {
                session.SpeakerId = speakerId;
                await _ctx.SaveChangesAsync();
            }
        }
    }

    public class ParticipantEventRepository : IParticipantEventRepository
    {
        private readonly EMSDbContext _ctx;
        public ParticipantEventRepository(EMSDbContext ctx) => _ctx = ctx;

        public async Task<IEnumerable<ParticipantEventDetails>> GetByParticipantAsync(string email) =>
            await _ctx.ParticipantEvents
                .Include(p => p.Event).ThenInclude(e => e!.Sessions).ThenInclude(s => s.Speaker)
                .Include(p => p.Session)
                .Where(p => p.ParticipantEmailId == email).ToListAsync();

        public async Task<bool> IsRegisteredAsync(string email, int eventId) =>
            await _ctx.ParticipantEvents.AnyAsync(p => p.ParticipantEmailId == email && p.EventId == eventId);

        public async Task RegisterAsync(ParticipantEventDetails record)
        {
            _ctx.ParticipantEvents.Add(record);
            await _ctx.SaveChangesAsync();
        }

        public async Task MarkAttendanceAsync(int id, bool attended)
        {
            var rec = await _ctx.ParticipantEvents.FindAsync(id);
            if (rec != null) { rec.IsAttended = attended; await _ctx.SaveChangesAsync(); }
        }

        public async Task<IEnumerable<ParticipantEventDetails>> GetByEventAsync(int eventId) =>
            await _ctx.ParticipantEvents
                .Include(p => p.Participant)
                .Where(p => p.EventId == eventId).ToListAsync();
    }
}
